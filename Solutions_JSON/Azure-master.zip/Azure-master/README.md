# Azure

The code in this repository is code that I developed and use to:

## Directories

* **solutions**: test customer scenarios & develop solutions around specific pain points
* **subscription**: deploy my lab containing core infrastructure & services to support my solutions
* **utilities**: solve problems around governance and management
